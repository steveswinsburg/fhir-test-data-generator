<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile Identifier
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Identifier</sch:title>
    <sch:rule context="f:Identifier">
      <sch:assert test="count(f:extension[@url = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status|26.0.0']) &gt;= 1">extension with URL = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status|26.0.0': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status|26.0.0']) &lt;= 1">extension with URL = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-services-identifier-status|26.0.0': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification']) &gt;= 1">extension with URL = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification']) &lt;= 1">extension with URL = 'http://digitalhealth.gov.au/fhir/hcpd/StructureDefinition/hi-org-classification': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:system) &gt;= 1">system: minimum cardinality of 'system' is 1</sch:assert>
      <sch:assert test="count(f:value) &gt;= 1">value: minimum cardinality of 'value' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Identifier/f:extension</sch:title>
    <sch:rule context="f:Identifier/f:extension">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:url) &gt;= 1">url: minimum cardinality of 'url' is 1</sch:assert>
      <sch:assert test="count(f:url) &lt;= 1">url: maximum cardinality of 'url' is 1</sch:assert>
      <sch:assert test="count(f:value[x]) &lt;= 1">value[x]: maximum cardinality of 'value[x]' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Identifier/f:extension/f:value[x] 1</sch:title>
    <sch:rule context="f:Identifier/f:extension/f:value[x]">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:text) &lt;= 1">text: maximum cardinality of 'text' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
